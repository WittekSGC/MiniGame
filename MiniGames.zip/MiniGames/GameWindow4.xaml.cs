﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MiniGames
{
    /// <summary>
    /// Логика взаимодействия для Game4.xaml
    /// </summary>
    public partial class GameWindow4 : Window
    {
        MainWindow Main;
        private bool ManualClosing = true;
        private Image[] StarsArray = new Image[5];

        int h, w, prevW, prevH;

        public GameWindow4(MainWindow main, WindowState state)
        {
            InitializeComponent();
            Main = main;
            WindowState = state;
            AddStars();

            SizeChanged += GameWindow4_SizeChanged;
            StateChanged += GameWindow4_StateChanged;
            Loaded += GameWindow4_Loaded;
        }

        private void GameWindow4_Loaded(object sender, RoutedEventArgs e)
        {
            AddClickGrid();
        }

        private void GameWindow4_StateChanged(object sender, EventArgs e)
        {
            ClickGridReSize();
        }

        private void GameWindow4_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            ClickGridReSize();
        }

        private void ClickGridReSize()
        {
            w = Convert.ToInt32((ActualWidth - 8) / 2) / 10;
            h = Convert.ToInt32((ActualHeight - 31) - 200) / 10;
            ist.Items.Add("w = " + w.ToString() + ", prevW = " + prevW.ToString());
            foreach (Canvas item in ClickGrid.Children)
            {
                item.Width = w;
                item.Height = h;
                item.Margin = new Thickness(item.Margin.Left / prevW * w, item.Margin.Top / prevH * h, 0, 0);
                foreach (UIElement child in item.Children)
                {
                    if (child is Image)
                    {
                        (child as Image).Width = item.Width;
                        (child as Image).Height = item.Height;
                        (child as Image).Margin = new Thickness(0);
                    }
                }                
            }
            prevH = h;
            prevW = w;
        }

        private void AddClickGrid()
        {
            w = Convert.ToInt32((792 / 2) / 10);
            h = Convert.ToInt32((569 - 200) / 10);
            prevH = h;
            prevW = w;
            //MessageBox.Show("h = " + h.ToString() + ", w = " + w.ToString());
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Canvas c = new Canvas()
                    {
                        Width = w,
                        Height = h,
                        HorizontalAlignment = HorizontalAlignment.Left,
                        VerticalAlignment = VerticalAlignment.Top,
                        Background = Brushes.Red
                    };
                    BitmapImage imgSrc = new BitmapImage();
                    imgSrc.BeginInit();
                    imgSrc.UriSource = new Uri("/Resources/Game2/star.png", UriKind.Relative);
                    imgSrc.EndInit();
                    Image r = new Image()
                    {
                        Source = imgSrc,
                        Width = w,
                        Height = h,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    c.Children.Add(r);
                    c.MouseEnter += R_MouseEnter;
                    c.MouseLeave += R_MouseLeave;
                    int marginTop = i * w;
                    int marginLeft = j * h;
                    c.Margin = new Thickness(marginTop, marginLeft, 0, 0);
                    ClickGrid.Children.Add(c);
                }
            }
        }

        private void R_MouseLeave(object sender, MouseEventArgs e)
        {
            Image r = (sender as Canvas).Children[0] as Image;
            DoubleAnimation doubleAnimationW = new DoubleAnimation(w, TimeSpan.FromSeconds(0.4));
            DoubleAnimation doubleAnimationH = new DoubleAnimation(h, TimeSpan.FromSeconds(0.4));
            r.BeginAnimation(WidthProperty, doubleAnimationW);
            r.BeginAnimation(HeightProperty, doubleAnimationH);

            ThicknessAnimation thicknessAnimation = new ThicknessAnimation(new Thickness(0, 0, 0, 0), TimeSpan.FromSeconds(0.4));
            r.BeginAnimation(MarginProperty, thicknessAnimation);
        }

        private void R_MouseEnter(object sender, MouseEventArgs e)
        {
            Image r = (sender as Canvas).Children[0] as Image;
            DoubleAnimation doubleAnimation = new DoubleAnimation(0, TimeSpan.FromSeconds(0.4));
            r.BeginAnimation(WidthProperty, doubleAnimation);
            r.BeginAnimation(HeightProperty, doubleAnimation);

            ThicknessAnimation thicknessAnimation = new ThicknessAnimation(new Thickness(w/2, h/2, 0, 0), TimeSpan.FromSeconds(0.4));
            r.BeginAnimation(MarginProperty, thicknessAnimation);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (ManualClosing)
                if (!(bool)new ModalWindow("Вы точно хотите прервать игру?", ModalWindowMode.TextWithYesNoBtn).ShowDialog())
                    e.Cancel = true;
                else
                {
                    Main.WindowState = WindowState;
                    Main.Show();
                }
        }

        private void AddStars()
        {
            BitmapImage imgSrc = new BitmapImage();
            imgSrc.BeginInit();
            imgSrc.UriSource = new Uri("/Resources/Game2/star.png", UriKind.Relative);
            imgSrc.EndInit();

            for (int i = 0; i < 5; i++)
            {
                StarsArray[i] = new Image
                {
                    Source = imgSrc,
                    Width = 50,
                    Height = 50,
                    Opacity = 0.4,
                    Margin = new Thickness(0, 0, 4, 0)
                };

                StarsPanel.Children.Add(StarsArray[i]);
            }
        }
    }
}
